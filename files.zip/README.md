# 📈 Stock Price Trend Analyzer

A real-time stock trend analysis web app built with **Python**, **Streamlit**, and **Plotly**.
Fetches live market data and generates **Buy / Hold / Sell signals** using classic technical indicators.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Streamlit](https://img.shields.io/badge/Streamlit-1.35-red)
![License](https://img.shields.io/badge/License-MIT-green)

---

## Features

- Live stock data via Yahoo Finance (`yfinance`)
- Candlestick chart with interactive zoom/pan
- Technical indicators: MA7, MA20, MA50, Bollinger Bands, RSI, MACD
- Automated Buy / Hold / Sell signal with reasoning
- Supports US stocks (AAPL, TSLA…) and Indian stocks (TCS.NS, INFY.NS…)
- CSV data export
- Dark-themed responsive UI

---

## Project structure

```
stock_analyzer/
├── app.py            # Streamlit frontend
├── analysis.py       # Data fetching & indicator logic
├── requirements.txt  # Python dependencies
├── LICENSE           # MIT License
└── README.md
```

---

## Setup & run locally

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/stock-trend-analyzer.git
cd stock-trend-analyzer

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
streamlit run app.py
```

The app opens at `http://localhost:8501` in your browser.

---

## Deploy on Streamlit Cloud (free)

1. Push this repo to GitHub.
2. Go to [share.streamlit.io](https://share.streamlit.io) and sign in with GitHub.
3. Click **New app** → select your repo → set main file to `app.py`.
4. Click **Deploy** — your app gets a public URL in ~2 minutes.

---

## Technical indicators explained

| Indicator | What it shows |
|-----------|--------------|
| MA7 / MA20 / MA50 | Simple Moving Averages — smooth out price noise |
| Bollinger Bands | Volatility envelope — price touching upper band = overbought |
| RSI (14) | Momentum oscillator — above 70 = overbought, below 30 = oversold |
| MACD | Trend-following momentum — crossover signals entries/exits |

---

## Signal logic

| Signal | Condition |
|--------|-----------|
| 🟢 BUY  | MA7 > MA20, RSI < 70, price above Bollinger mid-band |
| 🔴 SELL | MA7 < MA20, RSI > 30, price below Bollinger mid-band |
| 🟡 HOLD | No clear crossover — wait for confirmation |

---

## Disclaimer

> This project is for **educational purposes only** and does not constitute financial advice.
> Always do your own research before making investment decisions.

---

## License

This project is licensed under the [MIT License](LICENSE).

---

## Author

**Siddheya S Masurkar**  
B.E. Electronics Engineering, Savitribai Phule Pune University  
[siddheyamasurkar@gmail.com](mailto:siddheyamasurkar@gmail.com)
