"""
analysis.py - Stock data fetching and technical indicator calculations
"""

import yfinance as yf
import pandas as pd
import numpy as np


def fetch_stock_data(ticker: str, period: str = "3mo") -> pd.DataFrame:
    """
    Fetch historical stock data from Yahoo Finance.

    Args:
        ticker: Stock symbol e.g. 'AAPL', 'TCS.NS'
        period: One of '1mo', '3mo', '6mo', '1y', '2y'

    Returns:
        DataFrame with OHLCV columns
    """
    stock = yf.Ticker(ticker)
    df = stock.history(period=period)
    if df.empty:
        raise ValueError(f"No data found for ticker '{ticker}'. Check the symbol.")
    df.index = pd.to_datetime(df.index).tz_localize(None)
    return df


def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add technical indicators to the dataframe.

    Indicators added:
        MA7    - 7-day Simple Moving Average
        MA20   - 20-day Simple Moving Average
        MA50   - 50-day Simple Moving Average
        RSI    - 14-day Relative Strength Index
        BB_mid - Bollinger Band middle (20-day MA)
        BB_up  - Bollinger Band upper (mid + 2*std)
        BB_low - Bollinger Band lower (mid - 2*std)
        MACD   - MACD line (EMA12 - EMA26)
        Signal - MACD signal line (9-day EMA of MACD)
        Hist   - MACD histogram
    """
    close = df["Close"]

    df["MA7"]   = close.rolling(7).mean()
    df["MA20"]  = close.rolling(20).mean()
    df["MA50"]  = close.rolling(50).mean()

    # RSI
    delta = close.diff()
    gain  = delta.clip(lower=0).rolling(14).mean()
    loss  = (-delta.clip(upper=0)).rolling(14).mean()
    rs    = gain / loss.replace(0, np.nan)
    df["RSI"] = 100 - (100 / (1 + rs))

    # Bollinger Bands
    std           = close.rolling(20).std()
    df["BB_mid"]  = df["MA20"]
    df["BB_up"]   = df["MA20"] + 2 * std
    df["BB_low"]  = df["MA20"] - 2 * std

    # MACD
    ema12         = close.ewm(span=12, adjust=False).mean()
    ema26         = close.ewm(span=26, adjust=False).mean()
    df["MACD"]    = ema12 - ema26
    df["Signal"]  = df["MACD"].ewm(span=9, adjust=False).mean()
    df["Hist"]    = df["MACD"] - df["Signal"]

    return df


def generate_signal(df: pd.DataFrame) -> dict:
    """
    Generate a simple Buy / Hold / Sell signal from the latest data.

    Logic:
        BUY  - MA7 > MA20, RSI < 70 (not overbought), price above BB_mid
        SELL - MA7 < MA20, RSI > 30 (not oversold),  price below BB_mid
        HOLD - anything else
    """
    latest = df.iloc[-1]
    close  = latest["Close"]

    ma_bull   = latest["MA7"]  > latest["MA20"]
    rsi_ok    = latest["RSI"]  < 70
    above_mid = close > latest["BB_mid"]

    if ma_bull and rsi_ok and above_mid:
        action = "BUY"
        reason = "MA7 crossed above MA20, RSI not overbought, price above Bollinger mid-band."
        color  = "green"
    elif not ma_bull and latest["RSI"] > 30 and not above_mid:
        action = "SELL"
        reason = "MA7 crossed below MA20, price below Bollinger mid-band."
        color  = "red"
    else:
        action = "HOLD"
        reason = "No clear crossover signal. Wait for confirmation."
        color  = "orange"

    change_pct = df["Close"].pct_change().iloc[-1] * 100

    return {
        "action":     action,
        "reason":     reason,
        "color":      color,
        "close":      round(float(close), 2),
        "ma7":        round(float(latest["MA7"]),  2),
        "ma20":       round(float(latest["MA20"]), 2),
        "rsi":        round(float(latest["RSI"]),  2),
        "change_pct": round(float(change_pct),     2),
        "high":       round(float(df["High"].max()), 2),
        "low":        round(float(df["Low"].min()),  2),
        "volume":     int(latest["Volume"]),
    }
