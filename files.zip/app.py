"""
app.py - Streamlit frontend for the Stock Price Trend Analyzer
Run with:  streamlit run app.py
"""

import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from analysis import fetch_stock_data, compute_indicators, generate_signal

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Stock Trend Analyzer",
    page_icon="📈",
    layout="wide",
)

# ── Sidebar ─────────────────────────────────────────────────────────────────────
st.sidebar.title("📈 Stock Trend Analyzer")
st.sidebar.markdown("Analyze real-time stock trends using technical indicators.")

POPULAR = {
    "Apple (AAPL)":       "AAPL",
    "Google (GOOGL)":     "GOOGL",
    "Tesla (TSLA)":       "TSLA",
    "Microsoft (MSFT)":   "MSFT",
    "Amazon (AMZN)":      "AMZN",
    "TCS (TCS.NS)":       "TCS.NS",
    "Infosys (INFY.NS)":  "INFY.NS",
    "Reliance (RELIANCE.NS)": "RELIANCE.NS",
    "Custom ticker…":     "CUSTOM",
}

choice = st.sidebar.selectbox("Select stock", list(POPULAR.keys()))
if POPULAR[choice] == "CUSTOM":
    ticker = st.sidebar.text_input("Enter ticker symbol", placeholder="e.g. WIPRO.NS").upper().strip()
else:
    ticker = POPULAR[choice]

period = st.sidebar.selectbox(
    "Time period",
    ["1mo", "3mo", "6mo", "1y", "2y"],
    index=1,
)

indicators = st.sidebar.multiselect(
    "Overlay indicators",
    ["MA7", "MA20", "MA50", "Bollinger Bands"],
    default=["MA7", "MA20"],
)

show_macd = st.sidebar.checkbox("Show MACD panel", value=True)
show_rsi  = st.sidebar.checkbox("Show RSI panel",  value=True)

run = st.sidebar.button("Analyze ▶", use_container_width=True)

# ── Main ────────────────────────────────────────────────────────────────────────
st.title("📊 Stock Price Trend Analyzer")
st.caption("Real market data · Technical indicators · Buy / Hold / Sell signals")

if not run:
    st.info("👈 Select a stock and click **Analyze** to begin.")
    st.stop()

if not ticker:
    st.warning("Please enter a ticker symbol.")
    st.stop()

# ── Fetch & compute ──────────────────────────────────────────────────────────────
with st.spinner(f"Fetching data for {ticker}…"):
    try:
        df  = fetch_stock_data(ticker, period)
        df  = compute_indicators(df)
        sig = generate_signal(df)
    except ValueError as e:
        st.error(str(e))
        st.stop()

# ── Metric cards ────────────────────────────────────────────────────────────────
c1, c2, c3, c4, c5 = st.columns(5)
delta_str = f"{sig['change_pct']:+.2f}%"
c1.metric("Current price",  f"${sig['close']:,.2f}", delta_str)
c2.metric("Period high",    f"${sig['high']:,.2f}")
c3.metric("Period low",     f"${sig['low']:,.2f}")
c4.metric("RSI (14)",       f"{sig['rsi']:.1f}")
c5.metric("Volume",         f"{sig['volume']:,}")

st.divider()

# ── Signal banner ───────────────────────────────────────────────────────────────
color_map = {"BUY": "green", "SELL": "red", "HOLD": "orange"}
emoji_map  = {"BUY": "🟢", "SELL": "🔴", "HOLD": "🟡"}
action     = sig["action"]
st.markdown(
    f"### {emoji_map[action]} Signal: **{action}**  \n"
    f"<small>{sig['reason']}</small>",
    unsafe_allow_html=True,
)
st.caption(f"MA7 = ${sig['ma7']:,.2f}  |  MA20 = ${sig['ma20']:,.2f}  |  RSI = {sig['rsi']:.1f}")

st.divider()

# ── Build chart ─────────────────────────────────────────────────────────────────
rows   = 1 + int(show_macd) + int(show_rsi)
heights = [0.6] + [0.2] * (rows - 1)

fig = make_subplots(
    rows=rows, cols=1,
    shared_xaxes=True,
    row_heights=heights,
    vertical_spacing=0.04,
)

# Candlestick
fig.add_trace(go.Candlestick(
    x=df.index, open=df["Open"], high=df["High"],
    low=df["Low"], close=df["Close"],
    name="Price",
    increasing_line_color="#2ecc71",
    decreasing_line_color="#e74c3c",
), row=1, col=1)

# Moving averages
colors = {"MA7": "#e74c3c", "MA20": "#3498db", "MA50": "#9b59b6"}
for ma in ["MA7", "MA20", "MA50"]:
    if ma in indicators:
        fig.add_trace(go.Scatter(
            x=df.index, y=df[ma], name=ma,
            line=dict(color=colors[ma], width=1.5, dash="dot"),
        ), row=1, col=1)

# Bollinger Bands
if "Bollinger Bands" in indicators:
    fig.add_trace(go.Scatter(
        x=df.index, y=df["BB_up"], name="BB Upper",
        line=dict(color="rgba(180,180,180,0.6)", width=1),
    ), row=1, col=1)
    fig.add_trace(go.Scatter(
        x=df.index, y=df["BB_low"], name="BB Lower",
        line=dict(color="rgba(180,180,180,0.6)", width=1),
        fill="tonexty", fillcolor="rgba(180,180,180,0.1)",
    ), row=1, col=1)

# MACD
if show_macd:
    macd_row = 2
    fig.add_trace(go.Scatter(
        x=df.index, y=df["MACD"],   name="MACD",
        line=dict(color="#3498db", width=1.5),
    ), row=macd_row, col=1)
    fig.add_trace(go.Scatter(
        x=df.index, y=df["Signal"], name="Signal",
        line=dict(color="#e74c3c", width=1.5),
    ), row=macd_row, col=1)
    colors_hist = ["#2ecc71" if v >= 0 else "#e74c3c" for v in df["Hist"]]
    fig.add_trace(go.Bar(
        x=df.index, y=df["Hist"], name="Histogram",
        marker_color=colors_hist, opacity=0.6,
    ), row=macd_row, col=1)
    fig.update_yaxes(title_text="MACD", row=macd_row, col=1)

# RSI
if show_rsi:
    rsi_row = 2 + int(show_macd)
    fig.add_trace(go.Scatter(
        x=df.index, y=df["RSI"], name="RSI",
        line=dict(color="#f39c12", width=1.5),
    ), row=rsi_row, col=1)
    fig.add_hline(y=70, line_dash="dash", line_color="red",   opacity=0.5, row=rsi_row, col=1)
    fig.add_hline(y=30, line_dash="dash", line_color="green", opacity=0.5, row=rsi_row, col=1)
    fig.update_yaxes(title_text="RSI", range=[0, 100], row=rsi_row, col=1)

fig.update_layout(
    height=650,
    xaxis_rangeslider_visible=False,
    plot_bgcolor="#0e1117",
    paper_bgcolor="#0e1117",
    font=dict(color="#e0e0e0"),
    legend=dict(orientation="h", yanchor="bottom", y=1.01, xanchor="left", x=0),
    margin=dict(l=10, r=10, t=10, b=10),
)
fig.update_xaxes(gridcolor="#1e2530", showgrid=True)
fig.update_yaxes(gridcolor="#1e2530", showgrid=True)

st.plotly_chart(fig, use_container_width=True)

# ── Raw data table ───────────────────────────────────────────────────────────────
with st.expander("📄 View raw data"):
    cols_show = ["Open", "High", "Low", "Close", "Volume", "MA7", "MA20", "RSI"]
    st.dataframe(
        df[cols_show].tail(30).sort_index(ascending=False).round(2),
        use_container_width=True,
    )
    csv = df[cols_show].to_csv().encode()
    st.download_button("Download CSV", csv, f"{ticker}_data.csv", "text/csv")

# ── Disclaimer ───────────────────────────────────────────────────────────────────
st.divider()
st.caption(
    "⚠️ This tool is for educational purposes only. "
    "It does not constitute financial advice. "
    "Always do your own research before investing."
)
